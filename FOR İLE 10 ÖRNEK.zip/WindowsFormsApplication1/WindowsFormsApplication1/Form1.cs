﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // 1- Örnek: Adınızı 100 kez ekrana yazdıran programın algoritmasını yazınız.

            lstbox1.Items.Clear();
            for (int i = 1; i <= 100; i++)
            {
                lstbox1.Items.Add(i+" ÖDEV");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //2- Örnek: Ekrana 100 adet yıldız yazdıran programın algoritmasını yazınız.

            lstbox1.Items.Clear();
            for (int i = 1;  i <= 100;  i++)
            {
                lstbox1.Items.Add("*");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // 3- Örnek: Klavyeden girilen ismi ekrana 10 kez yazdıran programın algoritmasını yazınız.

            lstbox1.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                txtad.Text.ToString();
                lstbox1.Items.Add(txtad.Text);

            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // 4- Örnek: Klavyeden girilen ismi, girilen sayı kadar ekrana yazdıran programın algoritmasını yazınız.

            string isim = txtad.Text;
            int sayi=int.Parse(txtsayi1.Text);
            lstbox1.Items.Clear();
            for (int i = 1; i <=sayi; i++)
			{
			 lstbox1.Items.Add(isim);
			}
        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            // 5- Örnek: 1’den 100’e kadar olan sayıları ekrana yazdıran programın algoritmasını yazınız.

            lstbox1.Items.Clear();
            for (int i = 1; i <=100 ; i++)
            {
                lstbox1.Items.Add(i);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 6- Örnek: 0’dan 100’e kadar olan çift sayıları ekrana yazdıran programın algoritmasını yazınız.

            lstbox1.Items.Clear();
            for (int i = 0; i <= 100; i+=2)
            {
                lstbox1.Items.Add(i);
            }
        }

        private void btnyedi_Click(object sender, EventArgs e)
        {
            // 7- Örnek: 1’den 100’e kadar olan tam sayıların toplamını bulup ekranda gösteren programın algoritmasını yazınız.
            lstbox1.Items.Clear();
            int toplam = 1;
            for (int i = 1; i <=100; i++)
            {
                toplam = +i;
            }
                lstbox1.Items.Add(toplam);
                lbltoplam.Text = toplam.ToString();
        }

        private void btnsekiz_Click(object sender, EventArgs e)
        {
            // 8- Örnek: 1’den 50’ye kadar olan çift sayıların toplamını bulup ekranda gösteren programın algoritmasını yazınız.

            lstbox1.Items.Clear();
            int toplam = 1;
            for (int i = 1; i < 50; i+=2)
            {
                lstbox1.Items.Add(i);
                toplam = +i;
            }
            lbltoplam.Text = toplam.ToString();
        }
      }
   }

