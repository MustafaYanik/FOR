﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbeş = new System.Windows.Forms.Button();
            this.btnaltı = new System.Windows.Forms.Button();
            this.btnyedi = new System.Windows.Forms.Button();
            this.btndört = new System.Windows.Forms.Button();
            this.btnüç = new System.Windows.Forms.Button();
            this.btniki = new System.Windows.Forms.Button();
            this.btnbir = new System.Windows.Forms.Button();
            this.lstbox1 = new System.Windows.Forms.ListBox();
            this.txtad = new System.Windows.Forms.TextBox();
            this.txtsayi1 = new System.Windows.Forms.TextBox();
            this.lblad = new System.Windows.Forms.Label();
            this.lblsayı = new System.Windows.Forms.Label();
            this.lbltoplam = new System.Windows.Forms.Label();
            this.btnsekiz = new System.Windows.Forms.Button();
            this.btndokuz = new System.Windows.Forms.Button();
            this.btnon = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnbeş
            // 
            this.btnbeş.Location = new System.Drawing.Point(376, 164);
            this.btnbeş.Name = "btnbeş";
            this.btnbeş.Size = new System.Drawing.Size(75, 32);
            this.btnbeş.TabIndex = 0;
            this.btnbeş.Text = "5";
            this.btnbeş.UseVisualStyleBackColor = true;
            this.btnbeş.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnaltı
            // 
            this.btnaltı.Location = new System.Drawing.Point(376, 202);
            this.btnaltı.Name = "btnaltı";
            this.btnaltı.Size = new System.Drawing.Size(75, 32);
            this.btnaltı.TabIndex = 1;
            this.btnaltı.Text = "6";
            this.btnaltı.UseVisualStyleBackColor = true;
            this.btnaltı.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnyedi
            // 
            this.btnyedi.Location = new System.Drawing.Point(376, 240);
            this.btnyedi.Name = "btnyedi";
            this.btnyedi.Size = new System.Drawing.Size(75, 32);
            this.btnyedi.TabIndex = 2;
            this.btnyedi.Text = "7";
            this.btnyedi.UseVisualStyleBackColor = true;
            this.btnyedi.Click += new System.EventHandler(this.btnyedi_Click);
            // 
            // btndört
            // 
            this.btndört.Location = new System.Drawing.Point(376, 126);
            this.btndört.Name = "btndört";
            this.btndört.Size = new System.Drawing.Size(75, 32);
            this.btndört.TabIndex = 3;
            this.btndört.Text = "4";
            this.btndört.UseVisualStyleBackColor = true;
            this.btndört.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnüç
            // 
            this.btnüç.Location = new System.Drawing.Point(376, 88);
            this.btnüç.Name = "btnüç";
            this.btnüç.Size = new System.Drawing.Size(75, 32);
            this.btnüç.TabIndex = 4;
            this.btnüç.Text = "3";
            this.btnüç.UseVisualStyleBackColor = true;
            this.btnüç.Click += new System.EventHandler(this.button5_Click);
            // 
            // btniki
            // 
            this.btniki.Location = new System.Drawing.Point(376, 50);
            this.btniki.Name = "btniki";
            this.btniki.Size = new System.Drawing.Size(75, 32);
            this.btniki.TabIndex = 5;
            this.btniki.Text = "2";
            this.btniki.UseVisualStyleBackColor = true;
            this.btniki.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnbir
            // 
            this.btnbir.Location = new System.Drawing.Point(376, 12);
            this.btnbir.Name = "btnbir";
            this.btnbir.Size = new System.Drawing.Size(75, 32);
            this.btnbir.TabIndex = 6;
            this.btnbir.Text = "1";
            this.btnbir.UseVisualStyleBackColor = true;
            this.btnbir.Click += new System.EventHandler(this.button7_Click);
            // 
            // lstbox1
            // 
            this.lstbox1.FormattingEnabled = true;
            this.lstbox1.Location = new System.Drawing.Point(12, 12);
            this.lstbox1.Name = "lstbox1";
            this.lstbox1.Size = new System.Drawing.Size(120, 316);
            this.lstbox1.TabIndex = 7;
            // 
            // txtad
            // 
            this.txtad.Location = new System.Drawing.Point(138, 28);
            this.txtad.Name = "txtad";
            this.txtad.Size = new System.Drawing.Size(100, 20);
            this.txtad.TabIndex = 8;
            // 
            // txtsayi1
            // 
            this.txtsayi1.Location = new System.Drawing.Point(251, 28);
            this.txtsayi1.Name = "txtsayi1";
            this.txtsayi1.Size = new System.Drawing.Size(100, 20);
            this.txtsayi1.TabIndex = 9;
            // 
            // lblad
            // 
            this.lblad.AutoSize = true;
            this.lblad.Location = new System.Drawing.Point(141, 12);
            this.lblad.Name = "lblad";
            this.lblad.Size = new System.Drawing.Size(22, 13);
            this.lblad.TabIndex = 10;
            this.lblad.Text = "AD";
            // 
            // lblsayı
            // 
            this.lblsayı.AutoSize = true;
            this.lblsayı.Location = new System.Drawing.Point(248, 12);
            this.lblsayı.Name = "lblsayı";
            this.lblsayı.Size = new System.Drawing.Size(31, 13);
            this.lblsayı.TabIndex = 11;
            this.lblsayı.Text = "SAYI";
            // 
            // lbltoplam
            // 
            this.lbltoplam.AutoSize = true;
            this.lbltoplam.Location = new System.Drawing.Point(218, 60);
            this.lbltoplam.Name = "lbltoplam";
            this.lbltoplam.Size = new System.Drawing.Size(51, 13);
            this.lbltoplam.TabIndex = 13;
            this.lbltoplam.Text = "TOPLAM";
            // 
            // btnsekiz
            // 
            this.btnsekiz.Location = new System.Drawing.Point(376, 278);
            this.btnsekiz.Name = "btnsekiz";
            this.btnsekiz.Size = new System.Drawing.Size(75, 32);
            this.btnsekiz.TabIndex = 14;
            this.btnsekiz.Text = "8";
            this.btnsekiz.UseVisualStyleBackColor = true;
            this.btnsekiz.Click += new System.EventHandler(this.btnsekiz_Click);
            // 
            // btndokuz
            // 
            this.btndokuz.Location = new System.Drawing.Point(376, 316);
            this.btndokuz.Name = "btndokuz";
            this.btndokuz.Size = new System.Drawing.Size(75, 32);
            this.btndokuz.TabIndex = 15;
            this.btndokuz.Text = "9";
            this.btndokuz.UseVisualStyleBackColor = true;
            // 
            // btnon
            // 
            this.btnon.Location = new System.Drawing.Point(376, 354);
            this.btnon.Name = "btnon";
            this.btnon.Size = new System.Drawing.Size(75, 32);
            this.btnon.TabIndex = 16;
            this.btnon.Text = "10";
            this.btnon.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 509);
            this.Controls.Add(this.btnon);
            this.Controls.Add(this.btndokuz);
            this.Controls.Add(this.btnsekiz);
            this.Controls.Add(this.lbltoplam);
            this.Controls.Add(this.lblsayı);
            this.Controls.Add(this.lblad);
            this.Controls.Add(this.txtsayi1);
            this.Controls.Add(this.txtad);
            this.Controls.Add(this.lstbox1);
            this.Controls.Add(this.btnbir);
            this.Controls.Add(this.btniki);
            this.Controls.Add(this.btnüç);
            this.Controls.Add(this.btndört);
            this.Controls.Add(this.btnyedi);
            this.Controls.Add(this.btnaltı);
            this.Controls.Add(this.btnbeş);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbeş;
        private System.Windows.Forms.Button btnaltı;
        private System.Windows.Forms.Button btnyedi;
        private System.Windows.Forms.Button btndört;
        private System.Windows.Forms.Button btnüç;
        private System.Windows.Forms.Button btniki;
        private System.Windows.Forms.Button btnbir;
        private System.Windows.Forms.ListBox lstbox1;
        private System.Windows.Forms.TextBox txtad;
        private System.Windows.Forms.TextBox txtsayi1;
        private System.Windows.Forms.Label lblad;
        private System.Windows.Forms.Label lblsayı;
        private System.Windows.Forms.Label lbltoplam;
        private System.Windows.Forms.Button btnsekiz;
        private System.Windows.Forms.Button btndokuz;
        private System.Windows.Forms.Button btnon;
    }
}

